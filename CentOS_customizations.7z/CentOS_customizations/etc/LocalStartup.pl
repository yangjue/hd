#!/usr/bin/perl
# using the local perl install (/usr/bin/perl) makes it run *much* faster in BDC but requires an update to add IPC::System::Simple
# Includes
use strict;
use warnings;
my $VERSION = '$Id: //hdclone/CentOS_customizations/etc/LocalStartup.pl#15 $';
use English '-no_match_vars';
use Carp qw(croak carp);
use Fatal qw(open close);
use IPC::System::Simple qw(system capture $EXITVAL);
use Net::Ping;
use Sys::Hostname;
use File::Compare;
use Getopt::Long;
my ($help,$debug,$verbose,$locationonly,$testing);
GetOptions('locationonly' => \$locationonly, 'testing' => \$testing, 'debug' => \$debug, 'verbose' => \$verbose, 'help|?'=> \$help) || die "Errors in command line\n";

sub print_help {
    print
        "  Usage    : LocalStartup.pl [-debug]\n".
        "  Alt Usage : LocalStartup.pl -locationonly (this only returns the location)\n".
        "  Alt Usage2: LocalStartup.pl -testing (switches to the testing mirror for debug)\n".
        "  This script is used to prepare a std image system (win or linux)\n".
        "      to execute the version of startup.pl on the network\n".
        "  The goal of the network startup.pl is to mount useful common\n".
        "      shares and patch the OS in between image updates.\n".
        "\n".
        "  Report bugs to <HDCloning-Admin\@exchange.nvidia.com>.\n";
    return 0;
}

if (defined $help) {
    exit print_help();
}

# Globals
my $isLinux;
# The following is a list of all the nameservers in the company as of
# Q42013 and the p4proxy nearest to that location.
my %mirrors = (
    'GDNS'=>'GlobalDNS',
    'aus,Austin'=>'Austin',
    'txr,Richardson TX'=>'Austin',
    'ban,Bangalore'=>'Bangalore',
    'hyd,Hyderabad'=>'Bangalore',
    'pu,Pune'=>'Bangalore',
    'bvn,Beaverton'=>'Beaverton',
    'red,Redmond WA'=>'Beaverton',
#    'hk,Hong Kong'=>'HongKong',
    'brk,Reading'=>'Raleigh',
    'hun,Huntsville'=>'Raleigh',
    'nc,North Carolina'=>'Raleigh',
    'DC-E,1,5,12'=>'SantaClara',
    'DC-E,1,5,18'=>'SantaClara',
    'DC-E,3,1,16'=>'SantaClara',
    'de,Germany'=>'SantaClara',
    'deb,Berlin DE'=>'SantaClara',
    'fc,Fort Collins'=>'SantaClara',
    'frs,Sophia FR'=>'SantaClara',
    'hel,Helsinki'=>'SantaClara',
    'kor,Korea'=>'SantaClara',
    'mos,Moscow'=>'SantaClara',
    'par,Paris'=>'SantaClara',
    'sac,Sacramento'=>'SantaClara',
    'sc,Santa Clara'=>'SantaClara',
    'sc,Santa Clara,DC-1'=>'SantaClara',
    'sc,Santa Clara,DC-E,3,1,17'=>'SantaClara',
    'slc,Salt Lake City'=>'SantaClara',
    'stl,St. Louis'=>'SantaClara',
    'tok,Tokyo'=>'SantaClara',
    'ukdc,UKDC DC5 London'=>'SantaClara',
    'wur,Wurselen'=>'SantaClara',
    'zur,Zurich'=>'SantaClara',
    'maw,MA'=>'Westford',
    'maw,MA Westford'=>'Westford',
    'bj,Beijing'=>'Shanghai',
    'tia,TianJin China'=>'Shenzhen',
    'zj,Shanghai'=>'Shanghai',
    'szn,Shenzhen'=>'Shenzhen',
    'tp,Taipei'=>'Taipei',
    'tw,Taiwan'=>'Taipei',
    'testing'=>'testing',
);
# The following is a list of all the NFS mount points for the mirrors as
# of 2016-Q1.
my %nfspaths = (
    'GlobalDNS'=>'p4proxy-cloning.gdns.nvidia.com:/p4p/hdclone/',
    'Austin'    =>'netapp-tx04:/vol/scratch4/scratch.p4proxy_austin/hdclone/',
    'Bangalore' =>'i-netapp2:/vol/scratch7/scratch.p4proxy_bg/hdclone/',
    'Beaverton' =>'netapp-or04:/vol/scratch2/scratch.p4proxy_bvn/hdclone/',
#    'HongKong'  =>'p4proxy-hk:/p4p/hdclone/',
    'Raleigh'   =>'netapp-nc:/vol/scratch_p4proxy_nc/hdclone/nfsroot',
    'SantaClara'=>'sc-netapp41:/vol/scratch26/hdclone/',
    'Westford'  =>'netapp-nc:/vol/scratch_p4proxy_nc/hdclone/',
    'Shanghai'  =>'netapp-zj04:/vol/scratch4/p4proxy-zj/hdclone/',
    'Shenzhen'  =>'netapp-sz:/vol/scratch2/p4proxy-szn/hdclone/',
    'Taipei'    =>'netapp-tw:/vol/scratch11/p4proxy-taipei/hdclone/',
    'testing'   =>'netapp46:/vol/scratch30/scratch.eng_disk_clone/',
);

##############################################################################
# Setup logging
##############################################################################

my $LOGPATH = '/var/log/LocalStartup.log';
my $VERBOSE = 2;
my $DEBUG   = 1;
my $NORMAL  = 0;

##############################################################################
# Is this Windows or Linux?
##############################################################################
if ( -d '/etc/init.d' )
{
    $isLinux = 1;
    #if (system('/usr/bin/clear') != 0) {
    #    croak("ERROR: Could not clear screen : $OS_ERROR");
    #}
}
else
{
    $isLinux = 0;
    if (system('cls') != 0) {
        croak("ERROR: Could not clear screen : $OS_ERROR");
    }
}

if (defined $locationonly) {
    print GetRegionOnly();
    exit 0;
}

##############################################################################
# Check if network is up
##############################################################################
my $globalPing = Net::Ping->new();
if ($isLinux) {
    my $timeData = localtime(time);
    open my $LOG, '>', $LOGPATH or croak("Could not open $LOGPATH : $OS_ERROR");
    print $LOG "Began LocalStartup.pl on: $timeData\n";
    close($LOG) or croak("Could not close $LOGPATH : $OS_ERROR");
}
else {
    # Command for starting NVATS in auto mode
    my $NVATSPath = q[C:\\Program Files (x86)\\NVIDIA Corporation\\NVAssets Tracker Service];
    my $NVATSFile = qq[$NVATSPath\\NVATS.exe];
    print "Debugging path= $NVATSPath\n" if (defined $debug);
    if ( -d $NVATSPath ) {
        if ( -e $NVATSFile ) {
            my $cmd = qq(start /b "" /D "$NVATSPath" "$NVATSFile" auto);
            if (!defined $debug) {
                print "Starting NVATS with cmd: $cmd\n";
            }
            else {
                print "Starting NVAssets Tracking Service\n";
            }
            # The empty double quotes after /b are because $NVATSPath has double quotes
            # in it, which start sets as the window title. We work around this by passing
            # an empty string before the actual command.
            system( "$cmd" );
        }
        else {
            print "I didn't find the NVATS executable at $NVATSFile so I'm skipping it\n";
        }
    }
    else {
        print "I didn't find the NVATS directory at $NVATSPath so I'm skipping it\n";
    }
}
my $timeData = localtime(time);
PrintnLog("Waiting for connection to nvidia.com... at $timeData\n",$NORMAL);

if ($globalPing->ping('nvidia.com'))
{
    PrintnLog("nvidia.com is reachable.\n",$DEBUG);
    NetworkTasks();
}
else
{
    PrintnLog("Waiting longer for connection to nvidia.com...\n",$NORMAL);
    my $MEDIUMWAIT =  8;
    my $LONGWAIT   = 10;
    my $err = sleep($MEDIUMWAIT);
    if ($err != $MEDIUMWAIT) {
        carp("WARNING: sleep command failed : $OS_ERROR. Return value: $err\n");
    }
    if ($globalPing->ping('nvidia.com'))
    {
        PrintnLog("nvidia.com is reachable.\n",$DEBUG);
        NetworkTasks();
    }
    else
    {
        PrintnLog("Waiting even longer for connection to nvidia.com...\n",$NORMAL);
        $err = sleep($LONGWAIT);
        if ($err != $LONGWAIT) {
            carp("Warning: sleep command failed : $OS_ERROR\nWith $err\n");
        }
        if ($globalPing->ping('nvidia.com'))
        {
            PrintnLog("nvidia.com is reachable.\n",$DEBUG);
            NetworkTasks();
        }
        else
        {
            PrintnLog("\n\nUh Oh...\nNo connection to the nvidia.com domain is"
                    . " available!!\n\nWe can\'t run the Nvidia Standard Image"
                    . " startup script without a network\nconnection, network"
                    . ' shares may be unavailable, and your scripts may not'
                    . " work.\n\n",$NORMAL);
            ConsolePressAnyKey();
        }
    }
}
$globalPing->close();
exit 0;

INIT {
    #  If, for some reason, windows croaked on a previous run: unmount the
    #  drive so this run won't fail because of conflicting mount points.
    if ( -d 'p:/' ) {
        UnMount();
    }
}
#################### Subroutines Only Below This Line ########################

##############################################################################
# Function: print messages to the screen and log them to /var/log/LocalStartup.log
##############################################################################
sub PrintnLog
{
    if ( @_ != 2 )
    {
        croak 'wrong Number of arguments: ' . @_ . " from @ARGV\n";
    }
    my $message     = shift;
    my $outputLevel = shift;
    my $text2log    = '';
    #normal messages are always printed to screen and log
    if ($outputLevel == $NORMAL) {
        print $message;
        $text2log = $text2log . $message;
    }
    #debug messages are always printed to the log but only shown on screen if -debug is invoked
    elsif ($outputLevel == $DEBUG) {
        print $message if (defined $debug);
        $text2log = $text2log . $message;
    }
    #verbose messages only printed to the screen and log if -verbose is invoked
    elsif ($outputLevel == $VERBOSE) {
        $text2log = $text2log . $message if (defined $verbose);
    }
    if ($isLinux) {
        open my $LOG, '>>', $LOGPATH or croak("Could not open $LOGPATH : $OS_ERROR");
        print $LOG $text2log;
        close($LOG) or croak("Could not close $LOGPATH : $OS_ERROR");
    }
    return;
}

##############################################################################
# Function: Ask user to 'Press any key to continue . . .'
##############################################################################
sub ConsolePressAnyKey
{
    if ($isLinux)
    {
        # Linux pause equivalent
        my $timer = 9;
        PrintnLog("Continuing in ${timer} seconds...",$NORMAL);
        $OUTPUT_AUTOFLUSH = 1;
        while ($timer) {
            $timer--;
            PrintnLog("${timer}...",$NORMAL);
            if (sleep(1) != 1) {
                carp("WARNING: sleep command failed : $OS_ERROR\n");
            }
        }
        $OUTPUT_AUTOFLUSH = 0;
        PrintnLog("\n",$NORMAL);
    }
    else
    {
        if (system('pause') != 0) {
            croak("ERROR: Could not clear screen : $OS_ERROR");
        }
    }
    return;
}

##############################################################################
# Function: Return the location as the exit value.  For use with /etc/network/if-up.d/nvidia
##############################################################################
sub GetRegionOnly
{
    my $location;
    if (defined $testing) {
        $location = 'testing';
    }
    else {
        $location = GetRegionalLocation();
    }
    my $nearestMirror = $mirrors{$location};
    if ( !defined($nearestMirror) || $nearestMirror eq '' )
    {
        croak("Failed to find the nearest mirror for your location: $location");
    }
    return $nearestMirror;
}


##############################################################################
# Function: Get the nameserver from /etc/resolv.conf
##############################################################################
sub GetNameserver
{
    open my $resolve_conf, '<', '/etc/resolv.conf' or croak("Could not open /etc/resolv.conf : $OS_ERROR");
    my @resolve_confData=<$resolve_conf>;
    close($resolve_conf)                           or croak("Could not close /etc/resolv.conf : $OS_ERROR");
    my $localNameserver;
    foreach my $line (@resolve_confData) {
        if ($line =~ m/^nameserver\s+(\d{1,3}[.]\d{1,3}[.]\d{1,3}[.]\d{1,3})$/xms ) {
            $localNameserver=$1;
            last;
        }
    }
    return $localNameserver;
}

##############################################################################
# Function: Get the regional DNS data from the local machine's DNS server
##############################################################################
sub GetRegionalLocation
{
    my $localRegion;
    my $regionalPing = Net::Ping->new();
    my $localDNSServer = 'missing';
    if ( $isLinux )
    {
        # Get DNS information using Linux method...
        #First step is to get the nameserver IP address
        #I've found that the awk of resolv.conf often fails at first boot
        if ( ! -f '/etc/resolv.conf' )
        {
            PrintnLog("Waiting for resolv.conf\n",$NORMAL);
            if (sleep(1) != 1) {
                carp("WARNING: sleep command failed : $OS_ERROR\n");
            }
            if ( ! -f '/etc/resolv.conf' )
            {
                PrintnLog("NV Cloning: waiting longer for resolv.conf\n",$NORMAL);
                if (sleep(2) != 2) {
                    carp("WARNING: sleep command failed : $OS_ERROR\n");
                }
            }
        }
        #the resolv.conf file should now exist but it seems like it takes at
        # least 2sec before it is valid
        if (sleep(2) != 2) {
            carp("WARNING: sleep command failed : $OS_ERROR\n");
        }
        my $localDNS_IP=GetNameserver();
        if ( !defined($localDNS_IP) || $localDNS_IP eq '' )
        {
            PrintnLog("Waiting for resolv.conf to be valid\n",$NORMAL);
            if (sleep(2) != 2) {
                carp("WARNING: sleep command failed : $OS_ERROR\n");
            }
            $localDNS_IP=GetNameserver();
            if ( !defined($localDNS_IP) || $localDNS_IP eq '' )
            {
                PrintnLog("Waiting longer for resolv.conf to be valid\n",$NORMAL);
                if (sleep(4) != 4) {
                    carp("WARNING: sleep command failed : $OS_ERROR\n");
                }
                $localDNS_IP=GetNameserver();
                if ( !defined($localDNS_IP) || $localDNS_IP eq '' )
                {
                    PrintnLog("Waiting even longer for resolv.conf to be valid\n",$NORMAL);
                    if (sleep(8) != 8) {
                        carp("WARNING: sleep command failed : $OS_ERROR\n");
                    }
                    $localDNS_IP=GetNameserver();
                }
            }
        }
        if ( !defined($localDNS_IP) || $localDNS_IP eq '' )
        {
            PrintnLog("NV Cloning: Failed to find a valid IP address for the nameserver: $localDNS_IP\n",$NORMAL);
            PrintnLog("NV CLoning: I'll fail back to Santa Clara\n",$NORMAL);
            $localRegion='sc,Santa Clara';
        }
        else
        {
            PrintnLog("NV Cloning: Found nameserver IP address: $localDNS_IP\n",$DEBUG);
            #next find the hostname for that IP address
            my $localDNSName = capture("/usr/bin/getent hosts $localDNS_IP");
            my $exit_value = $EXITVAL;
            if ($exit_value != 0) {
                PrintnLog("getent failed the first time\n",$NORMAL);
                if (sleep(1) != 1) {
                    carp("WARNING: sleep command failed : $OS_ERROR\n");
                }
                $localDNSName = capture("/usr/bin/getent hosts $localDNS_IP");
                $exit_value = $EXITVAL;
                if ($exit_value != 0) {
                    PrintnLog("getent failed the second time!\n",$NORMAL);
                    if (sleep(5) != 5) {
                        carp("WARNING: sleep command failed : $OS_ERROR\n");
                    }
                    $localDNSName = capture("/usr/bin/getent hosts $localDNS_IP");
                    $exit_value = $EXITVAL;
                }
            }
            chomp $localDNSName;
            PrintnLog("NV Cloning: Found raw name: $localDNSName\n",$DEBUG);
            if ($localDNSName =~ m/^\S+\s+(.+.nvidia.com)$/xms)
            {
                $localDNSName = $1;
                chomp $localDNSName;
                PrintnLog("NV Cloning: Found nameserver named: $localDNSName\n",$DEBUG);
                #now ask the nameserver for its location (and remove the " from the answer)
                my $localDNSTXT = capture("/usr/bin/dig +short TXT $localDNSName");
                if ($localDNSTXT =~ /\"(.*)\"/xms)
                {
                    $localRegion = $1;
                    $localRegion =~ s/\'//g;
                    $localRegion =~ s/\"//g;
                }
                else
                {
                    croak("Unable to find local DNS TXT from DNS server $localDNSServer");
                }
            }
            else
            {
                PrintnLog("NV Cloning: Failed to find a valid nameserver: $localDNSName\n",$NORMAL);
                PrintnLog("NV CLoning: I'll fail back to Santa Clara\n",$NORMAL);
                $localRegion='sc,Santa Clara';
            }
        }
    }
    else
    {
        # Get DNS information using Windows method...
        my $host = hostname;
        my $localDNSData = capture("nslookup $host");
        #PrintnLog("nslookup gave $localDNSData\n",$DEBUG);
        # Get "Server" line
        if ($localDNSData =~ /^Server:\s+(\S+[.]nvidia[.]com)/xms)
        {
            $localDNSServer=$1;
            #PrintnLog("localDNSServer=$localDNSServer\n",$DEBUG);
        }
        else
        {
            croak("Found localDNSData=$localDNSData which doesn't appear to be an nvidia.com name server");
        };

        # Get the TXT attribute for this local machine's DNS server
        my $localDNSTXT = capture("nslookup -type=TXT $localDNSServer");
        if ($localDNSTXT =~ /\"(.*)\"/xms)
        {
            $localRegion = $1;
            $localRegion =~ s/\'//g;
            $localRegion =~ s/\"//g;
        }
        else
        {
            croak("Unable to find local DNS TXT from DNS server $localDNSServer");
        };
    }
    PrintnLog("\nYour host\'s location based on DNS data:\n$localRegion\n\n",$DEBUG);
    if (!defined $locationonly) {
        PrintnLog("Your cloning mirror based on your location:\n$mirrors{$localRegion} @"
                . " $nfspaths{$mirrors{$localRegion}}\n\n",$NORMAL);
    }
     $regionalPing->close();
    if ( !defined($localRegion) || $localRegion eq '' )
    {
        croak('Failed to determine your location. Aborting');
    }
    return $localRegion;
}


##############################################################################
# Function: mount the desired cloning mirror
##############################################################################
sub MountMirror
{
    croak "MountMirror must have one and only one argument to tell it which mirror path to use, it got: @_" if @_ != 1;
    my $mirrorPath    = $_[0];
    if ( $isLinux ) {
        # First make sure that /nfs/nvidia/ is mounted to the nearest mirror
        my $autoSKEL='-fstype=nfs,ro,vers=3,nolock,tcp,rsize=32768,wsize=32768';
        my $newAutoFSConfig='/tmp/auto.nvidia';
        my $autoFSConfig   ='/etc/auto.nvidia';
        open my $autoFSFH, '>', $newAutoFSConfig or croak("Could not open $newAutoFSConfig : $OS_ERROR");
        print $autoFSFH "# NVIDIA Engineering Cloning system\n";
        print $autoFSFH "#    ***DO NOT EDIT***\n";
        print $autoFSFH "# This file was generated by /etc/LocalStartup.pl\n";
        print $autoFSFH "# The following enables the customizations that run at boot\n";
        print $autoFSFH "#startup $autoSKEL ${mirrorPath}/nfsroot/nvidia/startup/\n";
        print $autoFSFH "# The following loads the std images from the nearest mirror\n";
        print $autoFSFH "#images  $autoSKEL ${mirrorPath}/nfsroot/images/\n";
        print $autoFSFH "# The following allows this script to patch the OS\n";
        print $autoFSFH "patches $autoSKEL ${mirrorPath}/CentOS_customizations/\n";
        close($autoFSFH)                         or croak("Could not close $newAutoFSConfig : $OS_ERROR");
        if (compare($newAutoFSConfig,$autoFSConfig) == 0) {
            PrintnLog("Your $autoFSConfig is already up to date with the correct cloning mirror\n",$DEBUG);
        }
        else {
            PrintnLog("I'm writing the new mirror to $autoFSConfig and restarting autofs\n",$DEBUG);
            # the mirror appears to have changed so set the new auto.nvidia restart autofs
            if (system("chmod 644 $newAutoFSConfig") != 0) {
                croak("Could not: chmod 644 $newAutoFSConfig        : $OS_ERROR");
            }
            if (system("mv $newAutoFSConfig $autoFSConfig") != 0) {
                croak("Could not: mv $newAutoFSConfig $autoFSConfig : $OS_ERROR");
            }
            if (system('/etc/init.d/autofs stop; sleep 1; /etc/init.d/autofs start') != 0) {
                croak("Could not: /etc/init.d/autofs restart        : $OS_ERROR");
            }
            # add some wait time in case autofs takes a while
            if ( ! -f '/nfs/startup/startup.pl' ) {
                PrintnLog("Waiting for connection\n",$NORMAL);
                if (sleep(3) != 3) {
                    carp("WARNING: sleep command failed : $OS_ERROR\n");
                }
                if ( ! -f '/nfs/startup/startup.pl' ) {
                    PrintnLog("Waiting longer for connection\n",$NORMAL);
                    if (sleep(6) != 6) {
                        carp("WARNING: sleep command failed : $OS_ERROR\n");
                    }
                }
            }
        }
    }
    else {
        #windows mounts
        if (system("mount $mirrorPath p:") != 0) {
            croak("ERROR: Could not mount $mirrorPath p: : $OS_ERROR");
        }
        if ( -d 'p:/nfsroot/nvidia' ) {
            if ( -d 'p:/nfsroot/nvidia/startup' ) {
            }
            else {
                croak("Couldn't find directory p:/nfsroot/nvidia/startup so I cannot run p:/nfsroot/nvidia/startup/startup.pl\n");
            }
        }
        else {
            croak("Couldn't find directory p:/nfsroot/nvidia so I cannot run p:/nfsroot/nvidia/startup/startup.pl\n");
        }

        if ( -f 'p:/debian_customizations/etc/LocalStartup.pl' ) {
        }
        else {
            croak("Couldn't find file p:/debian_customizations/etc/LocalStartup.pl: something strange happened\n");
        }
    }
    return;
}

##############################################################################
# Function: unmount the cloning mirror
##############################################################################
sub UnMount {
    if ( ! $isLinux ) {
        #clean up the mounts in windows
        if (system('umount p:') != 0) {
            croak("ERROR: Could not umount p: : $OS_ERROR");
        }
    }
    return;
}

##############################################################################
# Function: Check p4 Id: tag and return version number
##############################################################################
sub CheckForVersion
{
    croak "CheckForVersion must have one and only one argument to tell it which file to check, it got: @_" if @_ != 1;
    my $fullPathFilename2check = $_[0];
    PrintnLog("you passed in $fullPathFilename2check\n",$VERBOSE);
    my ($filename2check,$regexPattern);
    if ($isLinux) {
        $regexPattern='.*\/(\S+)';
    }
    else {
        $regexPattern='.*\\\\(\S+)';
    }
    if ($fullPathFilename2check =~ m/$regexPattern/xms) {
        $filename2check=$1;
        PrintnLog("Using filename: $filename2check located at $fullPathFilename2check\n",$VERBOSE);
    }
    else {
        croak("Unable to find the filename in $fullPathFilename2check\n");
    }
    #open the file and grep it for the p4 $Id: tag.
    open my $file2check, '<', $fullPathFilename2check or croak "Can't open '$fullPathFilename2check': $OS_ERROR";
    my $version='none';
    my $IDstring='\$Id:'; #this is separated so that p4 doesn't wreck the regex by dropping the current file version in the regex
    while ( my $line = <$file2check> ) {
        if ($line=~m{$IDstring\s* .*/$filename2check\#(\d+).*$}xms) {
            $version=$1;
            PrintnLog("***My $fullPathFilename2check version is $version***\n",$VERBOSE);
            last;
        }
        else {
            #PrintnLog("processed:$line <===>^$IDstring\s* .*/$filename2check\#(\d+).*",$DEBUG);
        }
    }
    close $file2check                         or croak "Can't close '$fullPathFilename2check': $OS_ERROR";
    if ($version eq 'none') {
        PrintnLog("WARNING: unable to find a p4 tag in $filename2check\n",$NORMAL);
    }
    return $version;
}

##############################################################################
# Function: Update a local file with one from the cloning mirror
##############################################################################
sub UpdateLocalFile
{
    croak "UpdateLocalFile must have two filename arguments, it got: @_" if @_ != 2;
    my $new = $_[0];
    my $old = $_[1];
    #copy network file to local disk
    PrintnLog("*** Updating local file by copying $new -> $old ***\n",$NORMAL);
    if ( $isLinux )
    {
        #rsync will also create directories when necessary
        if (system("rsync -rlptD $new $old") !=0) { #don't preserve owner and group so that root owns these files
            croak("ERROR: Copy failed: $OS_ERROR");
        }
    }
    else
    {
        if (system("copy $new $old") !=0) {
            croak("ERROR: Copy failed: $OS_ERROR");
        }
    }
    return;
}

##############################################################################
# Function: Check for updates to key files
##############################################################################
sub CheckForUpdates
{
    croak "CheckForUpdates must have only one argument for the nearest mirror, it got: @_" if @_ != 1;
    my $nearestMirror = $_[0];
    my $nearestNFSpath=$nfspaths{$nearestMirror};
    #first check current file (any OS)
    #if the file doesn't exist then replace it.  If it does exist then only replace it if it is an old version
    #wrap this in a foreach loop?
    my %customizedTextFiles;
    my %updatedBinaryFiles;
    my %jobs2Run; #not yet implemented
    if ( $isLinux ) {
        %customizedTextFiles = (
            #'/etc/test'=>'/nfs/patches/etc/test',
            '/etc/LocalStartup.pl'          =>'/nfs/patches/etc/LocalStartup.pl',
            '/etc/NetworkManager/dispatcher.d/update-ypservers' => '/nfs/patches/etc/NetworkManager/dispatcher.d/update-ypservers',
            #'/etc/sudoers'                  =>'/nfs/patches/etc/sudoers',
            '/etc/init.d/initial_hostname'          =>'/nfs/patches/etc/init.d/initial_hostname',
            '/etc/sysconfig/network-scripts/nvidia' =>'/nfs/patches/etc/sysconfig/network-scripts/nvidia',
            #'/etc/bash.bashrc'              =>'/nfs/patches/etc/bash.bashrc',
            '/etc/rc.d/rc.local'                 =>'/nfs/patches/etc/rc.d/rc.local',
            #can I add back MDB'/etc/modules'                  =>'/nfs/patches/etc/modules',
            '/etc/auto.master'              =>'/nfs/patches/etc/auto.master',
            '/etc/simple_ddns.pl'           =>'/nfs/patches/etc/simple_ddns.pl',
            '/etc/udev/rules.d/70-persistent-net.rules'
                                            =>'/nfs/patches/etc/udev/rules.d/70-persistent-net.rules',
            '/etc/udev/rules.d/99-stdimage.rules'
                                            =>'/nfs/patches/etc/udev/rules.d/99-stdimage.rules',
#            '/etc/udev/rules.d/75-persistent-net-generator.rules'
#                                            =>'/nfs/patches/etc/udev/rules.d/75-persistent-net-generator.rules',
#            '/usr/local/bin/checkASPM'      =>'/nfs/patches/usr/local/bin/checkASPM',
#            '/usr/local/bin/latestMods'     =>'/nfs/patches/usr/local/bin/latestMods',
#            '/usr/local/bin/latestVBIOS'    =>'/nfs/patches/usr/local/bin/latestVBIOS',
#            '/usr/local/bin/updateNvflash'  =>'/nfs/patches/usr/local/bin/updateNvflash',
#            '/usr/local/bin/km'             =>'/nfs/patches/usr/local/bin/km',
#            '/etc/NVATS/NVAssetsService.py' =>'/nfs/patches/etc/NVATS/NVAssetsService.py',
#            '/etc/NVATS/nvml.py'            =>'/nfs/patches/etc/NVATS/nvml.py',
#            '/etc/NVATS/nvpex.py'           =>'/nfs/patches/etc/NVATS/nvpex.py',
#            '/etc/NVATS/pynvmlint.py'       =>'/nfs/patches/etc/NVATS/pynvmlint.py',
#            '/etc/NVATS/pynvml.py'          =>'/nfs/patches/etc/NVATS/pynvml.py',
            );
        %updatedBinaryFiles = (
#            '/etc/NVATS/iromflsh'           =>'/nfs/patches/etc/NVATS/iromflsh',
#            '/etc/NVATS/nvpex2'             =>'/nfs/patches/etc/NVATS/nvpex2',
#            '/etc/NVATS/Init'               =>'/nfs/patches/etc/NVATS/Init',
            );
    }
    else {
        %customizedTextFiles = (
            'C:\LocalStartup.pl'        =>'p:\debian_customizations\etc\LocalStartup.pl',
            );
    }
    foreach my $localFile (keys %customizedTextFiles) {
        PrintnLog("Checking text file:   $localFile against $customizedTextFiles{$localFile}\n",$DEBUG);
        my $destPath = $localFile;
        $destPath =~ s/^(.*\/).*$/$1/xmsg; #strip the filename off the end since I'm using rsync in UpdateLocalFile instead of cp
        PrintnLog("  transmuted $localFile into $destPath\n",$DEBUG);
        if ( -e $localFile ) {
            PrintnLog("  ++$localFile exists\n",$VERBOSE);
            my $localVersion = CheckForVersion($localFile);
            my $ToTVersion;
            if ( -e $customizedTextFiles{$localFile} ) {
                $ToTVersion  = CheckForVersion($customizedTextFiles{$localFile});
                PrintnLog("  ++$customizedTextFiles{$localFile} exists\n",$VERBOSE);
                if ($localVersion eq 'none' || ($ToTVersion ne 'none' && ($localVersion < $ToTVersion)) ) {
                    UpdateLocalFile($customizedTextFiles{$localFile},$destPath);
                }
                else {
                    PrintnLog("  Not updating localVersion $localVersion with ToT version $ToTVersion\n",$DEBUG);
                }
            }
            else {
                carp("I couldn't find $customizedTextFiles{$localFile} so I can't update it to $destPath\n");
            }
        }
        else {
            PrintnLog("  ++$localFile doesn't exists\n",$VERBOSE);
            UpdateLocalFile($customizedTextFiles{$localFile},$destPath);
        }
    }
    foreach my $localFile (keys %updatedBinaryFiles) {
        PrintnLog("Checking binary file: $localFile against $updatedBinaryFiles{$localFile}\n",$DEBUG);
        my $destPath = $localFile;
        $destPath =~ s/^(.*\/).*$/$1/xmsg; #strip the filename off the end since I'm using rsync in UpdateLocalFile instead of cp
        PrintnLog("  transmuted $localFile into $destPath\n",$DEBUG);
        if ( -e $localFile ) {
            PrintnLog("  ++$localFile exists\n",$VERBOSE);
        }
        else {
            PrintnLog("  ++$localFile doesn't exists\n",$VERBOSE);
        }
        if ( -e $updatedBinaryFiles{$localFile} ) {
            PrintnLog("  ++$updatedBinaryFiles{$localFile} exists\n",$VERBOSE);
            UpdateLocalFile($updatedBinaryFiles{$localFile},$destPath);
        }
        else {
            carp("I couldn't find $updatedBinaryFiles{$localFile} so I can't update it to $destPath\n");
        }
    }

    #future update check for patches to other operating systems
    return;
}

##############################################################################
# Function: Once the network is up run a few tasks
##############################################################################
sub NetworkTasks
{
    #get the location of the nearest mirror
    my $nearestMirror = GetRegionOnly();
    my $nearestNFSpath=$nfspaths{$nearestMirror};
    MountMirror($nearestNFSpath);
    CheckForUpdates($nearestMirror);
    RunRemoteStartupPl($nearestMirror);
    return;
}

##############################################################################
# Function: Run the local P4 mirror's startup.pl file
##############################################################################
sub RunRemoteStartupPl
{
    croak "RunRemoteStartupPl must have only one argument for the nearest mirror, it got: @_" if @_ != 1;
    my $nearestMirror = $_[0];
    my $nearestNFSpath=$nfspaths{$nearestMirror};
    if ( !defined($nearestNFSpath) || $nearestNFSpath eq '' )
    {
        croak("Failed to find the nearest NFS path for your nearest mirror: $nearestMirror");
    }

    # Mount the p4-proxy and kick-off the startup.pl script

    if ( $isLinux )
    {
        # Linux method
        if ( -f '/nfs/startup/startup.pl' )
        {
            my $networkStartupCmd="perl /nfs/startup/startup.pl -location=$nearestMirror";
            PrintnLog("I will now run: $networkStartupCmd\n\n",$DEBUG);
            if (system($networkStartupCmd) !=0) {
                croak("ERROR: Could not run $networkStartupCmd : $OS_ERROR\n");
            } else {
                PrintnLog("Completed: $networkStartupCmd\n",$VERBOSE);
            }
        }
        else
        {
            PrintnLog("Skipping startup.pl on CentOS\n",$DEBUG);# should a missing network startup.pl be fatal or a warning?
        }
    }
    else
    {
        # Windows method
        if ( -d 'p:/nfsroot/nvidia' ) {
            if ( -d 'p:/nfsroot/nvidia/startup' ) {
                if ( -f 'p:/nfsroot/nvidia/startup/startup.pl' ) {
                    my $networkStartupCmd="perl p:/nfsroot/nvidia/startup/startup.pl -location=$nearestMirror";
                    PrintnLog("I will now run: $networkStartupCmd\n\n",$DEBUG);
                    if (system($networkStartupCmd) !=0) {
                        croak("ERROR: Could not run $networkStartupCmd : $OS_ERROR\n");
                    } else {
                        PrintnLog("Completed: $networkStartupCmd\n",$VERBOSE);
                    }
                }
                else {
                    carp("Couldn't find file p:/nfsroot/nvidia/startup/startup.pl so I cannot run p:/nfsroot/nvidia/startup/startup.pl\n");
                }
            }
            else {
                carp("Couldn't find directory p:/nfsroot/nvidia/startup so I cannot run p:/nfsroot/nvidia/startup/startup.pl\n");
            }
        }
        else {
            carp("Couldn't find directory p:/nfsroot/nvidia so I cannot run p:/nfsroot/nvidia/startup/startup.pl\n");
        }
    }
    return;
}

#!/usr/bin/perl
# $Id: //hdclone/CentOS_customizations/etc/simple_ddns.pl#4 $
use strict;
use warnings;
use English '-no_match_vars';
use Carp qw(croak);
use Fatal qw( open close );

use IPC::System::Simple qw(capture system);

sub get_my_ip
{
    my $ipaddr='not connected';
    my $nm_tool = '/usr/bin/nm-tool';
    my @nmtool_output = capture("$nm_tool 2>/dev/null");
    my %nmtool_info = ();
    my $current_device='';
    foreach ( @nmtool_output ) {
        if ( /\AState:\s+(\S+)/xms ) {
            $nmtool_info{'Global Connectivity'} = $1;
            if ($1 ne 'connected') {
#                print "not connected (globally)\n";
                last;
            }
            else {
#                print "connected (globally)\n";
                next;
            }
        }
        if ( /\A-\sDevice:\s+(\S+)/xms ) {
            $current_device = $1;
#            print "Device: $1\n";
        }
        elsif ( /\A\s*Address:\s*(\d+[.]\d+[.]\d+[.]\d+)/xms ) {
            $nmtool_info{'ethernet'}{$current_device}->{'IPaddr'} = $1;
#            print "address: $1\n";
        }
        elsif ( /\A\s*Default:\s*(yes|no)/xms ) {
            $nmtool_info{'ethernet'}{$current_device}->{'Default'} = $1;
#            print "Default $1\n";
        }
        elsif ( /\A\s*State:\s*(\S+)/xms ) {
            $nmtool_info{'ethernet'}{$current_device}->{'State'} = $1;
#            print "State $1\n";
        }
        else {
            next;
        }
    }
    if ($nmtool_info{'Global Connectivity'} eq 'connected') {
        foreach my $device (keys %{ $nmtool_info{'ethernet'}}) {
            if ($nmtool_info{'ethernet'}{$device}->{'Default'} eq 'yes' && $nmtool_info{'ethernet'}{$device}->{'State'} eq 'connected') {
#                print "Found IP: $nmtool_info{'ethernet'}->{$device}->{'IPaddr'} on $device\n";
                $ipaddr=$nmtool_info{'ethernet'}{$device}->{'IPaddr'};
            }
        }
    }
    return $ipaddr;
}
my $logfile = "/var/log/dyndns.log";
open my $LOGFILE, ">", $logfile or croak("Could not open $logfile : $OS_ERROR\n");
my $ip = get_my_ip();
if ( "$ip" eq 'not connected' ) {
    print "Unable to find an adaper with an IPv4 address.\nMake sure you are connected to the network.\nAborting\n" or croak "Fail to print\n";
    exit 1
}

use Sys::Hostname;
my $hostname = lc(hostname());
my $starttime = capture('/bin/date');
print $LOGFILE "Started at:  $starttime\n" or croak "Could not print to $logfile\n";
print $LOGFILE "Hostname: $hostname, IP: $ip\n" or croak "Could not print to $logfile\n";
my $nsupdate_cmd =
    "/usr/bin/nsupdate <<EOM\n" .
    "update delete $hostname.client.nvidia.com\n" .
    "update add $hostname.client.nvidia.com 120 A $ip\n" .
    "send\n" .
#    "answer\n" .
    "EOM\n";
print $LOGFILE "nsupdate command: $nsupdate_cmd\n" or croak "Could not print to $logfile\n";
my $nsupdate_result = system(${nsupdate_cmd});
print $LOGFILE "nsupdate result: $nsupdate_result\n" or croak "Could not print to $logfile\n";
my $endtime = capture('/bin/date');
print $LOGFILE "Finished at:  $endtime\n" or croak "Could not print to $logfile\n";
close($LOGFILE) or croak "Could not print to $logfile\n";
